package com.example.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.example.data.Cart;
import com.example.data.PlacedOrder;
import com.example.pojo.CartTable;
import com.example.pojo.OrderDetailTable;
import com.example.pojo.OrderTable;
import com.example.pojo.PaymentTable;
import com.example.pojo.ProductTable;
import com.example.pojo.UserTable;


@Repository
public class PlaceOrderImp extends BaseRepository implements PlaceOrder {
	@Override
	@Transactional
	public boolean placeOrder(List<Cart> carts, String payType) {
		
		EntityManager entityManager=getEntityManager();
		//first get productTable, userTable from a specific Cart
		List<OrderDetailTable> orderDetailTables = new ArrayList<OrderDetailTable>();
		OrderTable newOrder = null;
		CartTable actualCart = null;
		UserTable user = null;
		actualCart = this.entityManager.find(CartTable.class, carts.get(0).getcId());
		user = actualCart.getUserTable();
		
		newOrder = new OrderTable();
		newOrder.setUserTable(user);
		this.entityManager.persist(newOrder); //save the order now get orderId
		for(Cart c : carts)
		{
			actualCart = this.entityManager.find(CartTable.class, c.getcId());
			// save orderDetails first
//			if(actualCart.getCQty()==0) continue;
			OrderDetailTable orderDetails = new OrderDetailTable();
			orderDetails.setOdDelieveryDate(new Date());
			orderDetails.setOdPurchaseDate(new Date());
			orderDetails.setOdPrice(actualCart.getProductTable().getPPrice());
			orderDetails.setOdQty(actualCart.getCQty());
			orderDetails.setOrderTable(newOrder);
			orderDetails.setProductTable(actualCart.getProductTable());
			this.entityManager.persist(orderDetails); //adding new OrderDetailsTable
			orderDetailTables.add(orderDetails); //this list is used by newOrder
			//now update ProductTable pQty!
			ProductTable product = actualCart.getProductTable();
			int actualProductQty = product.getPQty();
			int newProductQty = actualProductQty - actualCart.getCQty();
			product.setPQty(newProductQty); 
			this.entityManager.merge(product); //updating Product qty
			this.entityManager.remove(actualCart); //remove from cart as well
		}
		PaymentTable newPayment = new PaymentTable();
		newPayment.setPayType(payType); //setOrderTable pending!
		this.entityManager.persist(newPayment); //adding new Payment
		newOrder.setOrderDetailTables(orderDetailTables);
		newOrder.setPaymentTable(newPayment);
		this.entityManager.merge(newOrder); //update final OrderTable
		return true;
	}
	
	@Override
	public List<PlacedOrder> showPlacedOrders(int uId)
	{
		EntityManager entityManager=getEntityManager();
		String pType = "";
		List<PlacedOrder> orders = new ArrayList<PlacedOrder>();
		UserTable user = this.entityManager.find(UserTable.class, uId);
		String q = "from OrderTable where userTable=:x";
		Query query = (Query) this.entityManager.createQuery(q);
		query.setParameter("x", user);
		List<OrderTable> myOrders = query.getResultList();
		if(myOrders.size()!=0)
		{
			
			pType = myOrders.get(0).getPaymentTable().getPayType();
		}
		for(OrderTable ord : myOrders)
		{
			q = "from OrderDetailTable where orderTable=:y";
			query = (Query)this.entityManager.createQuery(q);
			query.setParameter("y", ord);
			List<OrderDetailTable> orderDetailTables = query.getResultList();
			for(OrderDetailTable o : orderDetailTables)
			{
				String pName = o.getProductTable().getPName();
				int pId = o.getProductTable().getPId();
				String pImage = o.getProductTable().getPImage1();
				String pBrand = o.getProductTable().getPBrand();
				int pPrice = o.getOdPrice();
				int pQty = o.getOdQty();
				String pOrderDate = o.getOdPurchaseDate().toString();
				orders.add(new PlacedOrder(pName,pId, pImage, pBrand, pPrice, pOrderDate,pQty,pType));
			}
		}
		return orders;
	}
	
	@Override
	public List<Cart> getCartOfUser(int uId) {
		// TODO Auto-generated method stub
		int totalPrice = 0;
		List<Cart> carts = new ArrayList<Cart>();
		UserTable user = (UserTable)this.entityManager.find(UserTable.class, uId);
		System.out.println("User is :"+user);
		String q = "from CartTable where userTable=:x";
		Query query = (Query)this.entityManager.createQuery(q);
		query.setParameter("x", user);
		List<CartTable> cartTables = query.getResultList();
		//System.out.println("Cart values are :"+query.getResultList().toString());
		for(CartTable c : cartTables)
		{
			int cId = c.getCId();
			int pId = c.getProductTable().getPId();
			int cQty = c.getProductTable().getPQty()>=c.getCQty() ? c.getCQty() : 0;
			String pName = c.getProductTable().getPName();
			String pBrand = c.getProductTable().getPBrand();
			int pPrice = c.getProductTable().getPPrice();
			totalPrice += pPrice*cQty;
			String pImage1 = c.getProductTable().getPImage1();
			carts.add(new Cart(pId,cQty,pName,pBrand,pPrice,cId,totalPrice,pImage1));
		}
		return carts;
	}
}
