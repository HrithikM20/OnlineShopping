package com.example.repository;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.query.Query;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;
import org.springframework.stereotype.Repository;

import com.example.data.AddProduct;
import com.example.data.ForgotPassword;
import com.example.data.PlacedOrder;
import com.example.data.Product;
import com.example.data.RetailerSignUp;
import com.example.exception.CustomerException;
import com.example.pojo.AdminTable;
import com.example.pojo.ProductTable;
import com.example.pojo.RetailerTable;
import com.example.pojo.UserTable;

@Repository
public class RetailerDAOImpl implements RetailerDAO {


	@PersistenceContext
	private EntityManager entityManager;
	
	private final int aId = 101;
	
	@Override
	@Transactional
	public RetailerTable getRetailerByEmail(String email) throws CustomerException{
		// TODO Auto-generated method stub
		String query = "from RetailerTable where rEmail=:x";
		RetailerTable user = null;
		Query q = null;
		try
		{
			q = (Query) this.entityManager.createQuery(query);
			q.setParameter("x", email);
			user = (RetailerTable)q.getSingleResult();
		}
		catch(NonUniqueResultException e)
		{
			return null;
		}
		catch(Exception e)
		{
			throw new CustomerException("Customer Not Exists");
		}
		
		return user;
	}
	
	
	@Override
	@Transactional
	public int addRetailer(RetailerSignUp newRetailer) {
		// TODO Auto-generated method stub
		AdminTable admin = this.entityManager.find(AdminTable.class,this.aId);
		System.out.println("Admin Found");
		RetailerTable user = new RetailerTable();
		user.setRName(newRetailer.getrName());
		user.setRPassword(newRetailer.getrPassword());
		user.setREmail(newRetailer.getrEmail());
		user.setRMobile(newRetailer.getrPhone());
		user.setAdminTable(admin);
		this.entityManager.persist(user);
		String q1 = "select count(*) from retailer_table";
		Query query1 = (Query) this.entityManager.createNativeQuery(q1);
		Number id = (Number) query1.getSingleResult();
		int uId = id.intValue();
		return uId;
	}




	@Override
	@Transactional
	public RetailerTable updateRetailer(RetailerSignUp updateRetailer) {
		// TODO Auto-generated method stub
		RetailerTable oldRetailer = this.entityManager.find(RetailerTable.class, updateRetailer.getrId());
		oldRetailer.setRName(updateRetailer.getrName());
		oldRetailer.setRPassword(updateRetailer.getrPassword());
		oldRetailer.setREmail(updateRetailer.getrEmail());
		oldRetailer.setRMobile(updateRetailer.getrPhone());
		this.entityManager.merge(oldRetailer);
		return oldRetailer;
	}

	
	@Override
	@Transactional
	public String deleteRetailerById(int rid) {
		RetailerTable r = this.entityManager.find(RetailerTable.class, rid);
		
		
		if(r!=null) {
                this.entityManager.remove(r);// based on PK
		        return "Deleted Successfully";
		}
		else
			return "No retailer  found";

		
	}
	@Override
	public List<RetailerSignUp> showAllRetailers() {
		// TODO Auto-generated method stub
		List<RetailerSignUp> retailers = new ArrayList<RetailerSignUp>();
		List<RetailerTable> retailerTables = this.entityManager.find(AdminTable.class, 101).getRetailerTables();
		for(RetailerTable r : retailerTables)
		{
			int rId = r.getRId();
			String rName = r.getRName();
			String rPassword = r.getRPassword();
			String rEmail = r.getREmail();
			String rPhone = r.getRMobile();
			retailers.add(new RetailerSignUp(rName, rEmail, rPassword, rPhone, rId));
		}
		return retailers;
	}

	@Override
	public RetailerSignUp getRetailerById(int rId) {
		// TODO Auto-generated method stub
		RetailerTable r = this.entityManager.find(RetailerTable.class, rId);
		String rName = r.getRName();
		String rPassword = r.getRPassword();
		String rEmail = r.getREmail();
		String rPhone = r.getRMobile();
		RetailerSignUp actualRetailer = new RetailerSignUp(rName, rEmail, rPassword, rPhone, rId);
		return actualRetailer;
	}
	
	
	
//	hrithik part
	@Override
	@Transactional
	public String deleteProductByrid(int rid,int pid) {
		
		RetailerTable retailer = this.entityManager.find(RetailerTable.class, rid);
		//ProductTable product = this.entityManager.find(ProductTable.class, pid);
		String deleteq = "from ProductTable where retailerTable=:x and pId=:y";
		Query query = (Query)this.entityManager.createQuery(deleteq);
		query.setParameter("x", retailer);
		query.setParameter("y", pid);
		List<ProductTable> productTables = query.getResultList();
		if(productTables!=null) {
		for(ProductTable productTable : productTables)
		{
			this.entityManager.remove(productTable);
		}
		  return "Deleted successfully";
		}
		else {
			return "no products available";
		}
	}
	

	

	@Override
	public Product getProductById(int pId) {
		// TODO Auto-generated method stub
		Product product = null;
		String getProductq = "select pImage1,pId,pName,pBrand,pPrice,pImage2,pDescription,pQty,pSubCategory,pCategory from ProductTable where pId=:x";
		Query query = (Query)this.entityManager.createQuery(getProductq);
		query.setParameter("x", pId);
		List<Object []> pro = query.getResultList();
		for(Object [] p : pro)
		{
			System.out.println("Products :"+p[0]+p[1]+Arrays.toString(p));
			String pImage1 = (String) p[0];
			String pName = 	(String) p[2];
			String pBrand = (String) p[3];
			int pPrice =  Integer.parseInt(String.valueOf(p[4]));
			String pImage2 = (String) p[5];
			String pDescription = (String) p[6];
			int pQty =  Integer.parseInt(String.valueOf(p[7]));
			String pSubCategory = (String) p[8];
			String pCategory = (String) p[9];
			product = new Product(pImage1,pImage2,pDescription,pId,pName,pBrand,pPrice,pQty,pSubCategory,pCategory);
		}
		return product;
		//return this.entityManager.find(ProductTable.class,pId); //for testing
	}
	
	
	@Override
	public int getRetailerByEmailAndPassword(String email, String password) throws CustomerException{
		// TODO Auto-generated method stub
		Query getRetailer = null;
		try
		{
			String query = "select rId from RetailerTable where rEmail=:x and rPassword=:y";
			getRetailer = (Query) this.entityManager.createQuery(query);
			getRetailer.setParameter("x", email);
			getRetailer.setParameter("y", password);
			System.out.println("Result is :"+getRetailer.getSingleResult());
		}
		catch(Exception e)
		{
			throw new CustomerException("Retailer Not Found");
		}
		return (int)getRetailer.getSingleResult();
	}
	
	


	@Override
	@Transactional
	public boolean addProduct(AddProduct product, int rId) {
		// TODO Auto-generated method stub
		RetailerTable retailer = this.entityManager.find(RetailerTable.class, rId);
		ProductTable productTable = new ProductTable();
		productTable.setPName(product.getpName());
		productTable.setPImage1(product.getpImage1());
		productTable.setPImage2(product.getpImage2());
		productTable.setPBrand(product.getpBrand());
		productTable.setPCategory(product.getpCategory());
		productTable.setPDescription(product.getpDescription());
		productTable.setPSubCategory(product.getpSubCategory());
		productTable.setPPrice(product.getpPrice());
		productTable.setPQty(product.getpQty());
		productTable.setRetailerTable(retailer);
		this.entityManager.persist(productTable);
		return true;
	}




	@Override
	@Transactional
	public AddProduct updateProduct(AddProduct updateProduct, int pId) {
		// TODO Auto-generated method stub
		ProductTable oldProduct = this.entityManager.find(ProductTable.class, pId);
		oldProduct.setPName(updateProduct.getpName());
		oldProduct.setPImage1(updateProduct.getpImage1());
		oldProduct.setPImage2(updateProduct.getpImage2());
		oldProduct.setPBrand(updateProduct.getpBrand());
		oldProduct.setPCategory(updateProduct.getpCategory());
		oldProduct.setPDescription(updateProduct.getpDescription());
		oldProduct.setPSubCategory(updateProduct.getpSubCategory());
		oldProduct.setPPrice(updateProduct.getpPrice());
		oldProduct.setPQty(updateProduct.getpQty());
		this.entityManager.merge(oldProduct);
		return updateProduct;
	}


	@Override
	public List<Product> showMyProducts(int rId) {
		// TODO Auto-generated method stub
		List<Product> products = new ArrayList<Product>();
		RetailerTable retailer = this.entityManager.find(RetailerTable.class, rId);
		String q = "from ProductTable where retailerTable=:x";
		Query query = (Query)this.entityManager.createQuery(q);
		query.setParameter("x", retailer);
		List<ProductTable> productTables = query.getResultList();
		for(ProductTable p : productTables)
		{
			String pImage1 = p.getPImage1();
			String pImage2 = p.getPImage2();
			String pDescription = p.getPDescription();
			int pId = p.getPId();
			String pName = p.getPName();
			String pBrand = p.getPBrand();
			int pPrice = p.getPPrice();
			int pQty = p.getPQty();
			String pSubCategory = p.getPSubCategory();
			String pCategory = p.getPCategory();
			products.add(new Product(pImage1, pImage2, pDescription, pId, pName, pBrand, pPrice,pQty,pSubCategory,pCategory));
		}
		return products;
	}

	

}

