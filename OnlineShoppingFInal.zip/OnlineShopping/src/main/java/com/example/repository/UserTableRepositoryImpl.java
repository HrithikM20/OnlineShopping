package com.example.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.data.Cart;
import com.example.data.ForgotPassword;
import com.example.exception.CustomerException;
import com.example.exception.UserNotFoundException;
import com.example.pojo.CartTable;
import com.example.pojo.RetailerTable;
import com.example.pojo.UserTable;

@Repository
public class UserTableRepositoryImpl extends BaseRepository implements UsersRepository {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public int getUserByEmailAndPassword(String email, String password) throws UserNotFoundException{
		// TODO Auto-generated method stub
		Query q = null;
		try
		{
			String query = "select uId from UserTable where uEmail=:x and uPassword=:y";
			q = (Query) this.entityManager.createQuery(query);
			q.setParameter("x", email);
			q.setParameter("y", password);
			System.out.println("Result is :"+q.getSingleResult());
		}
		catch(Exception e)
		{
			throw new UserNotFoundException("user not found");
		}
		return (int)q.getSingleResult();
	}
	
	//Update password by mail
	@Transactional
	@Override
 public int updatePasswordFromMail(ForgotPassword reset) throws UserNotFoundException
 {
	
		EntityManager entityManager = getEntityManager();
		String uEmail=reset.getEmail();
		Query query = entityManager.createQuery("select  u from UserTable u where u.uEmail = :vjob");
		query.setParameter("vjob",uEmail);
	
		UserTable existingUser= (UserTable)query.getSingleResult();
	
		int uId = existingUser.getUId();
		UserTable existingUser1 = this.entityManager.find(UserTable.class, uId);
		existingUser1.setUPassword(reset.getPassword());
		this.entityManager.merge(existingUser1);
		return 100;
			}
	
	@Transactional
	@Override
	 public int rupdatePasswordFromMail(ForgotPassword reset) throws CustomerException
	 {
		
			EntityManager entityManager = getEntityManager();
			String rEmail=reset.getEmail();
			Query query = (Query) entityManager.createQuery("select  r from RetailerTable r where r.rEmail = :vjob");
			query.setParameter("vjob",rEmail);
		
			RetailerTable existingUser= (RetailerTable)query.getSingleResult();
		
			int rId = existingUser.getRId();
			RetailerTable existingUser1 = this.entityManager.find(RetailerTable.class, rId);
			existingUser1.setRPassword(reset.getPassword());
			
		this.entityManager.merge(existingUser1);
				
				return 100;		 
	 }
	
	@Override
	public List<Cart> getCartOfUser(int uId) {
		// TODO Auto-generated method stub
		
		int totalPrice = 0;
		List<Cart> carts = new ArrayList<Cart>();
		UserTable user = (UserTable)this.entityManager.find(UserTable.class, uId);
		System.out.println("User is :"+user);
		String q = "from CartTable where userTable=:x";
		Query query = (Query)this.entityManager.createQuery(q);
		query.setParameter("x", user);
		
		List<CartTable> cartTables = query.getResultList();
		//System.out.println("Cart values are :"+query.getResultList().toString());
		for(CartTable c : cartTables)
		{
			int cId = c.getCId();
			int pId = c.getProductTable().getPId();
			int cQty = c.getProductTable().getPQty()>=c.getCQty() ? c.getCQty() : 0;
			String pName = c.getProductTable().getPName();
			String pBrand = c.getProductTable().getPBrand();
			int pPrice = c.getProductTable().getPPrice();
			totalPrice += pPrice*cQty;
			String pImage1 = c.getProductTable().getPImage1();
			carts.add(new Cart(pId,cQty,pName,pBrand,pPrice,cId,totalPrice,pImage1));
		}
		return carts;
	}


	@Override
	public UserTable getUserById(int uId) {
		// TODO Auto-generated method stub
		UserTable user = this.entityManager.find(UserTable.class, uId);
		System.out.println("User is :"+user);
		return user;
	}

	@Override
	public UserTable updateUser(long uId, UserTable user) {
		// TODO Auto-generated method stub
		return null;
	}

}