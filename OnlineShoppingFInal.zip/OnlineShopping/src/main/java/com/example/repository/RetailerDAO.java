package com.example.repository;

import java.util.List;

import com.example.data.AddProduct;
import com.example.data.ForgotPassword;
import com.example.data.Product;
import com.example.data.RetailerSignUp;
import com.example.exception.CustomerException;
import com.example.pojo.RetailerTable;

public interface RetailerDAO {
//	public int getRetailerByEmailAndPassword(String email, String password) throws CustomerException;
//	public boolean addProduct(AddProduct product, int rId);
//	public AddProduct updateProduct(AddProduct updateProduct, int pId);
//	public List<Product> showMyProducts(int rId);
	public int getRetailerByEmailAndPassword(String email, String password) throws CustomerException;
	public boolean addProduct(AddProduct product, int rId);
	public AddProduct updateProduct(AddProduct updateProduct, int pId);
	public List<Product> showMyProducts(int rId);
	public Product getProductById(int pId);
	public String deleteProductByrid(int rid,int pid);
	
	public RetailerTable getRetailerByEmail(String email) throws CustomerException;//hrithik
	public int addRetailer(RetailerSignUp newRetailer);
	public RetailerTable updateRetailer(RetailerSignUp updateRetailer);
	public List<RetailerSignUp> showAllRetailers();
	public RetailerSignUp getRetailerById(int rId);
	public String deleteRetailerById(int rid);//shakti
}