package com.example.repository;

import com.example.data.Cart;
import com.example.data.ForgotPassword;
import com.example.data.UserSignUp;
import com.example.exception.CustomerException;
import com.example.exception.UserNotFoundException;
import com.example.pojo.UserTable;

import java.util.List;

import org.springframework.stereotype.Repository;


@Repository
public interface UsersRepository {
	public int getUserByEmailAndPassword(String email, String password) throws UserNotFoundException;//saurav
	int updatePasswordFromMail(ForgotPassword reset) throws UserNotFoundException;//saurav
	int rupdatePasswordFromMail(ForgotPassword reset) throws CustomerException;
	public UserTable getUserById(int uId); //for testing
	
	public UserTable updateUser(long uId, UserTable user);
	public List<Cart> getCartOfUser(int uId);
}