package com.example.service;

import java.util.List;

import com.example.data.AddProduct;
import com.example.data.ForgotPassword;
import com.example.data.Product;
import com.example.data.RetailerSignUp;
import com.example.exception.CustomerException;

public interface RetailerService {
	
	public int loginRetailer(String rEmail, String rPassword) throws CustomerException;
	public boolean addProduct(AddProduct product, int rId);
	public AddProduct updateProduct(AddProduct updateProduct, int pId);
	public List<Product> getMyProducts(int rId);
	public RetailerSignUp getRetailerById(int rId);
	public Product getProductById(int pId);
	public String deleteProductByrid(int rid,int pid);
	public String deleteRetailerById(int rid);
	
	
}
