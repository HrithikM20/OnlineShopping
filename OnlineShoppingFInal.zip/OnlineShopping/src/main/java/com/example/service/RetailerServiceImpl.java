package com.example.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.data.AddProduct;
import com.example.data.Product;
import com.example.data.ForgotPassword;
import com.example.data.RetailerSignUp;
import com.example.exception.CustomerException;
import com.example.repository.RetailerDAO;

@Service
public class RetailerServiceImpl implements RetailerService {
	
	
	@Autowired
	private RetailerDAO retailerDAO;

	
	
	@Override
	public Product getProductById(int pId) {
		// TODO Auto-generated method stub
		return this.retailerDAO.getProductById(pId);
	}

	@Override
	public boolean addProduct(AddProduct product, int rId) {
		// TODO Auto-generated method stub
		return this.retailerDAO.addProduct(product, rId);
	}


	@Override
	public AddProduct updateProduct(AddProduct updateProduct, int pId) {
		// TODO Auto-generated method stub
		return this.retailerDAO.updateProduct(updateProduct, pId);
	}

	@Override
	public List<Product> getMyProducts(int rId) {
		// TODO Auto-generated method stub
		return this.retailerDAO.showMyProducts(rId);
	}

	@Override
	public int loginRetailer(String rEmail, String rPassword) throws CustomerException {
		// TODO Auto-generated method stub
		return this.retailerDAO.getRetailerByEmailAndPassword(rEmail, rPassword);
	}

	@Override
	public RetailerSignUp getRetailerById(int rId) {
		// TODO Auto-generated method stub
		return this.retailerDAO.getRetailerById(rId);
	}

	@Override
	public String deleteProductByrid(int rid,int pid) {
		
		return this.retailerDAO.deleteProductByrid(rid,pid);
		
	}
	@Override
	public String deleteRetailerById(int rid) {
		
		return this.retailerDAO.deleteRetailerById(rid);
		
	}
}