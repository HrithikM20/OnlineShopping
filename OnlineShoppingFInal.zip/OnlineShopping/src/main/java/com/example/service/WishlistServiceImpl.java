package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.exception.WishlistException;
import com.example.data.Wishlist;
import com.example.repository.WishlistDAO;



@Service
public class WishlistServiceImpl implements WishlistService {

	@Autowired
	private WishlistDAO wishlistDAO;

	
	@Override
	public boolean addToWishlist(int uId, int pId) {
		// TODO Auto-generated method stub
		return this.wishlistDAO.addToWishlist(uId, pId);
	}

	@Override
	public boolean deleteWishlist(int w_Id) throws WishlistException {
		// TODO Auto-generated method stub
		System.out.println(w_Id+" Service");
		return this.wishlistDAO.deleteWishlist(w_Id);
	}
	
	@Override
	public List<Wishlist> getWishlistValues(int uId) {
		// TODO Auto-generated method stub
		return this.wishlistDAO.getWishlistOfUser(uId);
	}

}
