package com.example.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.data.Cart;
import com.example.data.Login;
import com.example.data.PlacedOrder;
import com.example.data.UserSignUp;
import com.example.data.ForgotPassword;
import com.example.exception.CartException;
import com.example.exception.CustomerException;
import com.example.exception.UserNotFoundException;
import com.example.pojo.UserTable;

@Repository
public interface UserService {

	int updatePasswordFromMailService(ForgotPassword reset) throws UserNotFoundException;//saurav
	int rupdatePasswordFromMailService(ForgotPassword reset) throws CustomerException;
	public boolean placeOrder(List<Cart> carts, String payType);//saurav
	public List<PlacedOrder> getMyPlacedOrders(int uId);//saurav
	public int login(Login login) throws UserNotFoundException; //saurav
	public List<Cart> getCartValues(int uId);//saurav
	public int addUser(UserSignUp newUser);//athish
	public boolean addToCart(int uId, int pId);
	public boolean deleteCart(int cId) throws CartException;
	public boolean updateCart(int cId, int addOrMinus);
	public UserTable getUserById(int uId);

}
