package com.example.data;

public class RetailerSignUp {
	private int rId;
	private String rName;
	private String rEmail;
	private String rPassword;
	private String rPhone;
	
	public int getrId() {
		return rId;
	}
	public void setrId(int rId) {
		this.rId = rId;
	}
	
	
	public String getrName() {
		return rName;
	}
	public void setrName(String rName) {
		this.rName = rName;
	}
	public String getrEmail() {
		return rEmail;
	}
	public void setrEmail(String rEmail) {
		this.rEmail = rEmail;
	}
	public String getrPassword() {
		return rPassword;
	}
	public void setrPassword(String rPassword) {
		this.rPassword = rPassword;
	}
	public String getrPhone() {
		return rPhone;
	}
	public void setrPhone(String rPhone) {
		this.rPhone = rPhone;
	}
	public RetailerSignUp(String rName, String rEmail, String rPassword, String rPhone, int rId) {
		super();
		this.rName = rName;
		this.rEmail = rEmail;
		this.rPassword = rPassword;
		this.rPhone = rPhone;
		this.rId = rId;
	}
	
}
