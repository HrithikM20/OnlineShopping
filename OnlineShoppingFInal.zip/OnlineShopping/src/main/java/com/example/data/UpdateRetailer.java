package com.example.data;

public class UpdateRetailer {

}
