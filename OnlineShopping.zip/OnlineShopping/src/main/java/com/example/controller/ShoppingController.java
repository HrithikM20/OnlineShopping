package com.example.controller;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.data.AddProduct;
import com.example.data.Cart;
import com.example.data.ForgotPassword;
import com.example.data.Login;
import com.example.data.PlacedOrder;
import com.example.data.Product;
import com.example.data.RetailerSignUp;
import com.example.data.UserSignUp;
import com.example.data.Wishlist;
import com.example.exception.CustomerException;
import com.example.exception.UserNotFoundException;
import com.example.pojo.RetailerTable;
import com.example.service.AdminService;
import com.example.service.ProductService;
import com.example.service.RetailerService;
import com.example.service.UserServiceImp;
import com.example.service.WishlistServiceImpl;



@CrossOrigin
@RestController
@RequestMapping("")
public class ShoppingController {
	
	@Autowired
	UserServiceImp userServiceImp;
	
	@Autowired
	WishlistServiceImpl wishlistServiceImpl;
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private RetailerService retailerService;
	

	@Autowired
	private ProductService productService;

	@GetMapping(path = "/index") //passed
	public String home()
	{
		return "Welcome to EasyBuy ";
	}
	
	
//	============================athish  register module==================
	@PostMapping(path = "/addNewUser")//passed but phone blank
	public int addNewUser(@RequestBody UserSignUp newUser)
	{
		return this.userServiceImp.addUser(newUser);
	}
//	============================athish register module end==================
	
	
//	============================Saurav login and placedorder module==================
	@PostMapping(path = "/login")//passed 
	public int login(@RequestBody  Login login)
	{
		try {
			return this.userServiceImp.login(login);
		} catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -100;
		}
	}

	///Update password using email id
	
	@PutMapping(path = "/updateCustomer/reset") //passed
	public int getUserUpdated(@RequestBody ForgotPassword reset) throws UserNotFoundException {
		System.out.println("getUserUpdated() ");
		int ok=userServiceImp.updatePasswordFromMailService(reset);
		if(ok==100)
		{
			return 100;
		}
		else {
			return -100;
		}
		
	}
	
	@PutMapping(path = "/updateRetailer/reset") //passed
	public int getRetailerUpdated(@RequestBody ForgotPassword reset) throws CustomerException {
		System.out.println("getUserUpdated() ");
		int ok=userServiceImp.rupdatePasswordFromMailService(reset);
		if(ok==100)
		{
			return 100;
		}
		else {
			return -100;
		}
		
	}
	
	
	@GetMapping(path = "/getMyPlacedOrders/{uId}") // passed
	public List<PlacedOrder> sortProduct(@PathVariable String uId) {
		return this.userServiceImp.getMyPlacedOrders(Integer.parseInt(uId));
	}
	
	@PostMapping(path = "/placeOrder/{payType}") // passed
	public String placeOrder(@RequestBody List<Cart> carts, @PathVariable String payType) {
		boolean ok = this.userServiceImp.placeOrder(carts, payType);
		if (ok == true)
			return "Order Place Successfull";
		return "Order Place Failure";
	}
	

//	============================Saurav login and placedorder  module end ==================
	
//	============================athish wishlist module ==================
	
	@GetMapping(path = "/getMyWishlist/{uId}") //passed
	public List<Wishlist> getMyWishlist(@PathVariable String uId)
	{
		return this.wishlistServiceImpl.getWishlistValues(Integer.parseInt(uId));
	}
	
	
	@PostMapping(path = "/addToMyWishlist/{uId}/{pId}") 
	public String updateMyWishlist(@PathVariable int uId, @PathVariable int pId)
	{
		boolean ok = this.wishlistServiceImpl.addToWishlist(uId,pId);
		if(ok==true)
			return "Product Added to Wishlist Successfull";
		return "Cannot Add Product to Wishlist";
	}
	
	@DeleteMapping(path = "/deleteMyWishlist/{w_Id}") 
	public String deleteMyWishlist(@PathVariable int w_Id)
	{
		try
		{
			boolean ok = this.wishlistServiceImpl.deleteWishlist(w_Id);
			return "Wish Unchecked";
		}
		catch(Exception e)
		{
		  System.out.print(e.getMessage());
		  return "error";
		}
	}
	

//	============================athish wishlist module end==================
	

//	============================Shakti Admin module==================
	@PostMapping(path = "/addNewRetailer") //passed
	public int addNewRetailer(@RequestBody RetailerSignUp newRetailer)
	{
		return this.adminService.addRetailer(newRetailer);
	}
	 

	@PutMapping(path = "/updateRetailer") //passed
	public RetailerTable updateRetailer(@RequestBody RetailerSignUp updateRetailer)
	{
		return this.adminService.updateRetailer(updateRetailer);
	}
	
	@GetMapping(path = "/showAllRetailers")//passed
	public List<RetailerSignUp> showAllRetailers()
	{
		return this.adminService.showAllRetailers();
	}
	
	@GetMapping(path = "/getRetailerById/{rId}") //passed
	public RetailerSignUp getRetailerById(@PathVariable String rId)
	{
		return this.adminService.getRetailerById(Integer.parseInt(rId));
	}
	

	@DeleteMapping(path = "/deleteProductByrid/{rId}/{pId}")
	public String deleteProductByrid(@PathVariable String rId,@PathVariable String pId)
	{
			
		return this.retailerService.deleteProductByrid(Integer.parseInt(rId),Integer.parseInt(pId));
	}
	
//	============================Shakti Admin module end==================
	
	//===========Hrithik Module
	
	@PostMapping(path = "/retailerLogin") //passed
	public int retailerLogin(@RequestBody Login login)
	{
		try {
			return this.retailerService.loginRetailer(login.getEmail(), login.getPassword());
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -100;
		}
	}
	
	
	
	@PostMapping(path = "/addProduct/{rId}") //passed
	public boolean addProduct(@RequestBody AddProduct product, @PathVariable String rId)
	{
		return this.retailerService.addProduct(product, Integer.parseInt(rId));
	}
	
	
	
	@PutMapping(path = "/updateProduct/{pId}") //passed
	public AddProduct updateProduct(@RequestBody AddProduct updateProduct, @PathVariable String pId)
	{
		return this.retailerService.updateProduct(updateProduct, Integer.parseInt(pId));
	}
	
	@GetMapping(path = "/getMyProduct/{rId}")//passed
	public List<Product> getMyProduct(@PathVariable String rId)
	{
		return this.retailerService.getMyProducts(Integer.parseInt(rId));
	}

	@GetMapping(path = "/getProductById/{pId}") //passed
	public Product getProductById(@PathVariable String pId)
	{
		return this.retailerService.getProductById(Integer.parseInt(pId));
	}
	

	//===========Hrithik end module

//	===================subhangi user module start===========================
	
	@GetMapping(path = "/getMyCart/{uId}") //passed
	public List<Cart> getMyCart(@PathVariable String uId)
	{
		return this.userServiceImp.getCartValues(Integer.parseInt(uId));
	}
	
//	2. ADD PRODUCT TO CART OF A USER:---
	
	@GetMapping(path = "/addToMyCart/{uId}/{pId}") //passed
	public String addToMyCart(@PathVariable String uId, @PathVariable String pId) {
		boolean ok = this.userServiceImp.addToCart(Integer.parseInt(uId), Integer.parseInt(pId));
		if (ok == true)
			return "Product Added to Cart Successfull";
		return "Cannot Add Product to Cart";
	}


//	3. UPDATE CART BY ADDING OR SUBTRACTING A PRODUCT FROM IT :-----
	
//	BY DEFAULT MIN PRODUCT AVAILABLE SHOULD BE 1
//	PRODUCT QUANTITY in cart should not exceed actual product quantity in product table

	@GetMapping(path = "/updateMyCart/{cId}/{addOrMinus}") //passed
	public String updateMyCart(@PathVariable String cId, @PathVariable String addOrMinus)
	{
		boolean ok = this.userServiceImp.updateCart(Integer.parseInt(cId),Integer.parseInt(addOrMinus));
		if(ok==true)
			return "Cart Updated Successfull";
		return "Cannot Update Cart";
	}



//	4. DELETE A PRODUCT FROM CART USING CART_ID:-----
	
	@DeleteMapping(path = "/deleteMyCart/{cId}")//passed
	public String deleteMyCart(@PathVariable String cId) {
		try {
			boolean ok = this.userServiceImp.deleteCart(Integer.parseInt(cId));
			return "deleted succesfully";

		} catch (Exception e) {
			return "not found";
		}
	}

//	2.SEARCH PRODUCT
	
	@GetMapping(path = "/getProductBySearch/{pSearch}") // passed
	public List<Product> getProductBySearch(@PathVariable String pSearch) {
		return this.productService.getProductBySearch(pSearch);
	}


//	3.SORT PRODUCT
	
	@GetMapping(path = "/sortProduct/{by}/{order}") // passed
	public List<Product> sortProduct(@PathVariable String by, @PathVariable String order) {
		return this.productService.sortProduct(by, Integer.parseInt(order));
	}



//	4.FILTER PRODUCT
	
	@GetMapping(path = "/filterProduct/{brand}/{startingPrice}/{endingPrice}") // passed
	public List<Product> sortProduct(@PathVariable String brand, @PathVariable String startingPrice,
			@PathVariable String endingPrice) {
		return this.productService.filterProduct(brand, Integer.parseInt(startingPrice), Integer.parseInt(endingPrice));
	}


	//	===================subhangi user module start===========================
}


