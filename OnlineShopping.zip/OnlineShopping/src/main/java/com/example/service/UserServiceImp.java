package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.data.Cart;
import com.example.data.ForgotPassword;
import com.example.data.Login;
import com.example.data.PlacedOrder;
import com.example.data.UserSignUp;
import com.example.repository.CartDAO;
import com.example.repository.PlaceOrder;
import com.example.repository.UserRegisterDAO;
import com.example.exception.CartException;
import com.example.exception.CustomerException;
import com.example.exception.UserNotFoundException;
import com.example.pojo.UserTable;
import com.example.repository.UserTableRepositoryImpl;

@Repository
public class UserServiceImp implements UserService {
	
	@Autowired
	private UserRegisterDAO userDAO;
	
	@Autowired
	UserTableRepositoryImpl userRepoImp;
	
	@Autowired
	private CartDAO cartDAO;
	
	@Autowired
	PlaceOrder placeOrder;

//===================================saurav module ==============================
	@Override
	public int updatePasswordFromMailService(ForgotPassword reset) throws UserNotFoundException {
		// TODO Auto-generated method stub
		System.out.println("select all users service...");
		return userRepoImp.updatePasswordFromMail(reset);
	}
	
	@Override
	public int rupdatePasswordFromMailService(ForgotPassword reset) throws CustomerException {
		// TODO Auto-generated method stub
		System.out.println("select all users service...");
		return this.userRepoImp.rupdatePasswordFromMail(reset);
	}
	
	
	@Override
	public List<PlacedOrder> getMyPlacedOrders(int uId) {
		// TODO Auto-generated method stub
		return this.placeOrder.showPlacedOrders(uId);
	}
	
	@Override
	public boolean placeOrder(List<Cart> carts, String payType) {
		// TODO Auto-generated method stub
		return this.placeOrder.placeOrder(carts, payType);
	}
	
	
	@Override
	public int login(Login login) throws UserNotFoundException{
		int id = this.userRepoImp.getUserByEmailAndPassword(login.getEmail(),login.getPassword());
		return id;
	}
	
	@Override
	public List<Cart> getCartValues(int uId) {
		// TODO Auto-generated method stub
		return this.placeOrder.getCartOfUser(uId);
	}
//	===================================saurav module end==============================
	
//	===================================athish module ==============================
	@Override
	public int addUser(UserSignUp newUser) {
		int id = 0;
		try
		{
			UserTable user = this.userDAO.getUserByEmail(newUser.getuEmail());
			return -1;
		}
		catch(NullPointerException e)
		{
			return -1;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			id = this.userDAO.addUser(newUser);
		}
		return id;
	}
//	===================================athish module end==============================




	@Override
	public boolean addToCart(int uId, int pId) {
		// TODO Auto-generated method stub
		return this.cartDAO.addToCart(uId, pId);
	}

	@Override
	public boolean updateCart(int cId, int addOrMinus) {
		// TODO Auto-generated method stub
		return this.cartDAO.updateCart(cId,addOrMinus);
	}
	

	@Override
	public boolean deleteCart(int cId) throws CartException {
		// TODO Auto-generated method stub
		return this.cartDAO.deleteCart(cId);
	}

	@Override
	public UserTable getUserById(int uId) {
		// TODO Auto-generated method stub
		return this.userRepoImp.getUserById(uId);
	}
	
}
