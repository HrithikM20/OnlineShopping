package com.example.service;

import java.util.List;

import com.example.exception.WishlistException;
import com.example.data.Wishlist;

public interface WishlistService {

	
	public boolean addToWishlist(int uId, int pId);
	public boolean deleteWishlist(int wId) throws WishlistException ;
	public List<Wishlist> getWishlistValues(int uId);
}