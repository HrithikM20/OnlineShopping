package com.example.repository;

import javax.persistence.EntityManager;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.example.data.UserSignUp;
import com.example.pojo.UserTable;
import com.example.exception.CustomerException;


@Repository
public class UserDAOImpl implements UserRegisterDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public UserTable getUserByEmail(String email) throws CustomerException{
		String query = "from UserTable where uEmail=:x";
		UserTable user = null;
		Query q = null;
		try
		{
			q = (Query) this.entityManager.createQuery(query);
			q.setParameter("x", email);
			user = (UserTable)q.getSingleResult();
		}
		catch(NonUniqueResultException e)
		{
			return null;
		}
		catch(Exception e)
		{
			throw new CustomerException("Customer Not Exists");
		}
		
		return user;
	}
	

	
	@Override
	@Transactional
	public int addUser(UserSignUp newUser)
	{
		UserTable user = new UserTable();
		user.setUName(newUser.getuName());
		user.setUPassword(newUser.getuPassword());
		user.setUAddress(newUser.getuAddress());
		user.setUEmail(newUser.getuEmail());
		user.setUMobile(newUser.getuPhone());
		this.entityManager.persist(user);
		String q1 = "select max(u_id) from user_table";
		Query query1 = (Query) this.entityManager.createNativeQuery(q1);
		Number id = (Number) query1.getSingleResult();
		int uId = id.intValue();
		return uId;
	}


	

}
