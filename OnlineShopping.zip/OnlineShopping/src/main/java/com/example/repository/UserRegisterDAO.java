package com.example.repository;

import com.example.data.UserSignUp;
import com.example.exception.CustomerException;
import com.example.pojo.UserTable;

public interface UserRegisterDAO {
	public UserTable getUserByEmail(String email) throws CustomerException;//athish
	public int addUser(UserSignUp newUser);//athish
}
