package com.example.repository;

import java.util.List;

import com.example.exception.WishlistException;
import com.example.data.Wishlist;


public interface WishlistDAO {
	public boolean addToWishlist(int uId, int pId);
	public boolean deleteWishlist(int wId) throws WishlistException;
	public List<Wishlist> getWishlistOfUser(int uId);
}