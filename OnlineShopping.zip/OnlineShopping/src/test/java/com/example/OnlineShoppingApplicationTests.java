package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.exception.UserNotFoundException;
import com.example.repository.UserTableRepositoryImpl;

@SpringBootTest
class OnlineShoppingApplicationTests {

	
	
	@Autowired
	UserTableRepositoryImpl userRepo;
	
	@Test
	public void loginUser() throws UserNotFoundException {
		
		int id = userRepo.getUserByEmailAndPassword("annelle@gmail.com", "pass@0099");
		if (id > 0)
			System.out.println("Login SucessFul");
		else
			System.out.println("Login Unsuccessful");
	}
	
	@Test
	void contextLoads() {
	}

}
